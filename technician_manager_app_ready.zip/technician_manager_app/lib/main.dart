import 'package:flutter/material.dart';

void main() => runApp(const TechnicianManagerApp());

class TechnicianManagerApp extends StatelessWidget {
  const TechnicianManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'إدارة الفنيين',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorSchemeSeed: Colors.indigo,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    DashboardPage(),
    TechniciansPage(),
    FaultsPage(),
    AreasPage(),
    PermissionsPage(),
  ];

  final titles = [
    'الرئيسية',
    'الفنيين',
    'الأعطال',
    'المناطق و GPS',
    'الصلاحيات',
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(titles[index]),
          centerTitle: false,
          actions: [
            IconButton(
              tooltip: 'الإشعارات',
              onPressed: () => _showNotifications(context),
              icon: const Icon(Icons.notifications_none),
            ),
          ],
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(radius: 30, child: Icon(Icons.person)),
                    SizedBox(height: 10),
                    Text('المالك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('صلاحيات كاملة'),
                  ],
                ),
              ),
              for (int i = 0; i < titles.length; i++)
                ListTile(
                  selected: index == i,
                  leading: Icon([
                    Icons.dashboard,
                    Icons.engineering,
                    Icons.build_circle,
                    Icons.location_on,
                    Icons.admin_panel_settings,
                  ][i]),
                  title: Text(titles[i]),
                  onTap: () {
                    setState(() => index = i);
                    Navigator.pop(context);
                  },
                ),
            ],
          ),
        ),
        body: pages[index],
      ),
    );
  }

  void _showNotifications(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => const Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('آخر التنبيهات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              SizedBox(height: 16),
              ListTile(
                leading: Icon(Icons.location_off, color: Colors.red),
                title: Text('الموقع غير متاح'),
                subtitle: Text('أحمد محمد — 2:15 م'),
              ),
              ListTile(
                leading: Icon(Icons.check_circle, color: Colors.green),
                title: Text('تم إكمال عطل'),
                subtitle: Text('محمد علي — 2:08 م'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('ملخص اليوم', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: const [
            StatCard(title: 'الفنيين', value: '24', icon: Icons.engineering),
            StatCard(title: 'حاضرين الآن', value: '18', icon: Icons.login),
            StatCard(title: 'أعطال اليوم', value: '67', icon: Icons.build),
            StatCard(title: 'متوسط الإنجاز', value: '72%', icon: Icons.percent),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('إنجاز الفنيين'),
        const TechnicianProgress(name: 'أحمد محمد', completed: 5, total: 10),
        const TechnicianProgress(name: 'محمد علي', completed: 8, total: 10),
        const TechnicianProgress(name: 'محمود حسن', completed: 3, total: 5),
        const SizedBox(height: 24),
        const SectionTitle('حالة GPS'),
        const ListTile(
          leading: Icon(Icons.circle, color: Colors.green),
          title: Text('18 فني داخل مناطقهم'),
          subtitle: Text('آخر تحديث مستمر'),
        ),
        const ListTile(
          leading: Icon(Icons.location_off, color: Colors.red),
          title: Text('2 موقع غير متاح'),
          subtitle: Text('يحتاجان إلى متابعة'),
        ),
      ],
    );
  }
}

class TechniciansPage extends StatelessWidget {
  const TechniciansPage({super.key});

  @override
  Widget build(BuildContext context) {
    final names = ['أحمد محمد', 'محمد علي', 'محمود حسن', 'إبراهيم خالد'];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FilledButton.icon(
          onPressed: () => _newAccount(context),
          icon: const Icon(Icons.person_add),
          label: const Text('إنشاء حساب فني'),
        ),
        const SizedBox(height: 16),
        ...names.map((n) => Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(n),
            subtitle: const Text('المنطقة: طنطا 1 • حاضر'),
            trailing: const Icon(Icons.chevron_left),
          ),
        )),
      ],
    );
  }

  void _newAccount(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إنشاء حساب فني'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(decoration: InputDecoration(labelText: 'اسم الفني')),
            TextField(decoration: InputDecoration(labelText: 'اسم المستخدم')),
            TextField(decoration: InputDecoration(labelText: 'كلمة المرور')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('إنشاء')),
        ],
      ),
    );
  }
}

class FaultsPage extends StatelessWidget {
  const FaultsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FilledButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.add),
          label: const Text('إسناد أعطال'),
        ),
        const SizedBox(height: 16),
        const TechnicianProgress(name: 'أحمد محمد — الشهر الحالي', completed: 5, total: 10),
        const ListTile(
          leading: Icon(Icons.check_circle, color: Colors.green),
          title: Text('عطل #1042 — تم الإصلاح'),
          subtitle: Text('تم الإغلاق اليوم 11:20 ص'),
        ),
        const ListTile(
          leading: Icon(Icons.refresh, color: Colors.orange),
          title: Text('عطل #1038 — أُعيد فتحه'),
          subtitle: Text('تم خصم الإنجاز بعد عودة العطل'),
        ),
      ],
    );
  }
}

class AreasPage extends StatelessWidget {
  const AreasPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.map),
            title: const Text('تحديد منطقة جديدة'),
            subtitle: const Text('اختيار الموقع + نصف القطر من 100 إلى 1000 متر'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () {},
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.location_on),
            title: Text('طنطا 1'),
            subtitle: Text('نصف القطر: 200 متر • 6 فنيين'),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.notifications_active),
            title: Text('الانصراف التلقائي'),
            subtitle: Text('بعد 60 دقيقة من فقدان الموقع'),
          ),
        ),
      ],
    );
  }
}

class PermissionsPage extends StatelessWidget {
  const PermissionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final permissions = [
      'عرض الفنيين',
      'إنشاء حسابات',
      'تعديل منطقة الفني',
      'عرض الحضور',
      'إسناد الأعطال',
      'تعديل الأعطال',
      'عرض نسب الإنجاز',
      'إعادة فتح عطل وخصم الإنجاز',
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('صلاحيات المديرين', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.person)),
            title: Text('مدير 1'),
            subtitle: Text('صلاحيات مخصصة'),
            trailing: Icon(Icons.edit),
          ),
        ),
        ...permissions.map((p) => SwitchListTile(
          title: Text(p),
          value: p == 'عرض الفنيين' || p == 'عرض الحضور',
          onChanged: (_) {},
        )),
        const Divider(),
        const ListTile(
          leading: Icon(Icons.lock, color: Colors.red),
          title: Text('صلاحيات المالك المخفية'),
          subtitle: Text('تعديل نسبة فني • الحضور من أي مكان'),
        ),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 165,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 28),
              const SizedBox(height: 10),
              Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              Text(title),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold));
}

class TechnicianProgress extends StatelessWidget {
  final String name;
  final int completed;
  final int total;
  const TechnicianProgress({super.key, required this.name, required this.completed, required this.total});

  @override
  Widget build(BuildContext context) {
    final pct = total == 0 ? 0.0 : completed / total;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text('${(pct * 100).round()}%'),
              ],
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: pct),
            const SizedBox(height: 6),
            Text('$completed من $total مكتمل • ${total - completed} متبقي'),
          ],
        ),
      ),
    );
  }
}

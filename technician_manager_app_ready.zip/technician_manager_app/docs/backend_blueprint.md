# Backend blueprint

Core entities:
- users
- technicians
- managers
- permissions
- areas
- technician_area_assignments
- attendance_sessions
- location_events
- faults
- fault_events
- work_periods
- progress_adjustments
- notifications
- audit_logs

Owner-only permissions should be enforced server-side, not merely hidden in UI:
- attendance_anywhere
- adjust_progress
- manage_system_permissions

Progress:
actual_percentage = completed_valid_faults / assigned_faults * 100
displayed_percentage = actual_percentage + owner_adjustment (with server-defined bounds)

When a completed fault is reopened:
- create fault event
- reverse the completion from valid progress
- record who reopened it and why
- recalculate weekly/monthly progress

# Technician Manager App — MVP

نسخة أولية لتطبيق إدارة الفنيين.

## التقنية
- Flutter
- Arabic RTL UI
- Architecture prepared for backend/API integration

## الموجود في النسخة
- Owner dashboard
- Technicians
- Technician profile/photo placeholder
- Attendance summary
- Fault/task progress
- Weekly/monthly percentage
- Managers & granular permissions UI
- Areas/GPS settings UI
- Owner-only controls UI

## تشغيل المشروع
1. ثبّت Flutter.
2. نفّذ:
   flutter pub get
3. شغّل:
   flutter run

> هذه النسخة Prototype للواجهة والمنطق المحلي. ربط GPS الحقيقي بالخلفية، Push Notifications، وقاعدة البيانات يحتاج Backend وإعدادات Android إضافية.
